package com.hsi.service;

import java.util.List;

import com.hsi.model.Resume;

public interface ResumeService {

	List<Resume> findAll();

}